package net.softsociety.issho.security;

import java.util.Collection;

public interface UserService {

	
	//Collection<GrantedAutority> getAutorities(String username);
	
}
