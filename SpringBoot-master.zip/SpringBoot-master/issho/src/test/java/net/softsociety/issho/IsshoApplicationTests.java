package net.softsociety.issho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsshoApplicationTests {

	@Test
	void contextLoads() {
	}

}
